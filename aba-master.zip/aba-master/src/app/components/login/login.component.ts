import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AbaService } from '../../services/aba-service.service';
import { HttpResponse } from '@angular/common/http';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private abaService: AbaService
  ) { }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.loginForm = this.formBuilder.group({
      username: ['N271673', Validators.required],
      password: ['India@345', Validators.required]
    });
  }
  login() {
    if(this.loginForm.valid) {
      this.abaService.login(this.loginForm.value).subscribe((data)  => {
        this.router.navigate(['dashboard/home']);
      });
    }
  }
}
