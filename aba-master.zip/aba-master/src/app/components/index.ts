import { AppComponent } from '../app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './dashboard/home/home.component';
import { CustomersComponent } from './dashboard/customers/customers.component';
import { CustomerDetailsComponent } from './dashboard/customer-details/customer-details.component';
import { InvoicesComponent } from './dashboard/invoices/invoices.component';
import { AuditLogsComponent } from './dashboard/audit-logs/audit-logs.component';
import { ReportsComponent } from './dashboard/reports/reports.component';
import { BulkUploadsComponent } from './dashboard/bulk-uploads/bulk-uploads.component';
import { ContactComponent } from './dashboard/contact/contact.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AddCustomerComponent } from './dashboard/add-customer/add-customer.component';
import { CustomerInformationComponent } from './dashboard/customer-details/customer-information/customer-information.component';
import { BankInformationComponent } from './dashboard/customer-details/bank-information/bank-information.component';
import { PaymentTransactionsComponent } from './dashboard/customer-details/payment-transactions/payment-transactions.component';
import { InvoiceDetailsComponent } from './dashboard/customer-details/invoice-details/invoice-details.component';
import { PaymentPlansComponent } from './dashboard/customer-details/payment-plans/payment-plans.component';
import { NotesComponent } from './dashboard/customer-details/notes/notes.component';
import { ContactInformationComponent } from './dashboard/customer-details/contact-information/contact-information.component';
import { BankAccountComponent } from './dashboard/customer-details/bank-information/bank-account/bank-account.component';
import { BillPackageComponent } from './dashboard/customer-details/bank-information/bill-package/bill-package.component';

export const components: any[] = [
    AppComponent,LoginComponent,HomeComponent,CustomersComponent,CustomerDetailsComponent
    ,InvoicesComponent,AuditLogsComponent,ReportsComponent,BulkUploadsComponent,ContactComponent
    ,DashboardComponent,AddCustomerComponent,CustomerInformationComponent,BankInformationComponent
    ,PaymentTransactionsComponent,InvoiceDetailsComponent,PaymentPlansComponent,NotesComponent
    ,ContactInformationComponent,BankAccountComponent,BillPackageComponent
];

export * from '../app.component';
export * from './login/login.component';
export * from './dashboard/home/home.component';
export * from './dashboard/customers/customers.component';
export * from './dashboard/customer-details/customer-details.component';
export * from './dashboard/invoices/invoices.component';
export * from './dashboard/audit-logs/audit-logs.component';
export * from './dashboard/reports/reports.component';
export * from './dashboard/bulk-uploads/bulk-uploads.component';
export * from './dashboard/contact/contact.component';
export * from './dashboard/dashboard.component';
export * from './dashboard/add-customer/add-customer.component';
export * from './dashboard/customer-details/bank-information/bank-account/bank-account.component';
export * from './dashboard/customer-details/bank-information/bill-package/bill-package.component';
