import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { AuditLogService } from '../../../services/audit-log/audit-log.service';
import { IAuditLog, IAuditResponse, IAdditionalAuditDetails } from '../../../models/audit-log.model';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ViewAuditModalComponent } from '../../../modals/view-audit-modal/view-audit-modal.component';

@Component({
  selector: 'app-audit-logs',
  templateUrl: './audit-logs.component.html',
  styleUrls: ['./audit-logs.component.css']
})
export class AuditLogsComponent implements OnInit {

  constructor(
      private auditLogsService: AuditLogService,
      private formBuilder: FormBuilder,
      private modalService: BsModalService
  ) { }
  auditLogTable: IAuditResponse[];
  showLoader: boolean = true;
  auditlogSearchForm: FormGroup;
  bsModalRef: BsModalRef;
  subjectAreaList: any[] = [
        {
          key: 'Customer Information',
          value: 'Customer Information'
        },
        {
          key: 'Bank Information',
          value: 'Bank Information'
        },
        {
          key: 'Payment Plans',
          value: 'Payment Plans'
        },
        {
          key: 'Notes',
          value: 'Notes'
        },
        {
          key: 'Contacts',
          value: 'Contacts'
        },
        {
          key: 'Invoice',
          value: 'Invoice'
        },
        {
          key: 'Payment Transactions',
          value: 'Payment Transactions'
        }
  ];

  operationList: any[] = [
    {
      key: '',
      value: 'Operation'
    },
    {
      key: 'New',
      value: 'New'
    },
    {
      key: 'Updated',
      value: 'Updated'
    },
  ];
  ngOnInit() {
    this.displayAuditLogs();
    this.createForm();
  }

  createForm() {
    this.auditlogSearchForm = this.formBuilder.group({
      fromDate: null,
      toDate: null,
      user: [],
      psuid: [],
      subjectArea: [],
      operation: []
    });
  }

  displayAuditLogs() {
    this.auditLogsService.getAllAuditLogs().subscribe((data: IAuditLog) => {
      if(!data) {
        this.showLoader = true;
      } else {
        this.showLoader = false;
        this.auditLogTable = data.responseObject;
      }
    });
  }

  searchAuditLogs() {
    this.auditLogsService.searchAuditLogs(this.auditlogSearchForm.value).subscribe((data: IAuditLog) => {
      if(!data) {
        this.showLoader = true;
      } else {
        this.showLoader = false;
        this.auditLogTable = data.responseObject;
      }
    });
  }

  openModalWithComponent(item: IAuditResponse) {
    this.auditLogsService.getAdditionalDetails(item.sysuaaId).subscribe((data: IAdditionalAuditDetails[]) => {
      const initialState = {
        additionalDetails: data,
        basicDetails: item
      };
      this.bsModalRef = this.modalService.show(ViewAuditModalComponent, {initialState});
      this.bsModalRef.content.closeBtnName = 'Close';
    });
  }

}
