import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { InvoiceService } from '../../../services/invoice/invoice.service';
import { IInvoiceResponse, IInvoiceSearchResponse, IAdditionalInvoiceResponse } from '../../../models/invoice.model';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ViewInvoiceModalComponent } from '../../../modals/view-invoice-modal/view-invoice-modal.component';

@Component({
  selector: 'app-invoices',
  templateUrl: './invoices.component.html',
  styleUrls: ['./invoices.component.css']
})
export class InvoicesComponent implements OnInit {

  constructor(
      private invoiceService: InvoiceService,
      private formBuilder: FormBuilder,
      private modalService: BsModalService
  ) { }
  invoiceTableData: IInvoiceResponse[];
  showLoader: boolean = true;
  invoiceStatusList: any[];
  invoiceSearchForm: FormGroup;
  bsModalRef: BsModalRef;
  ngOnInit() {
    this.displayInvoice();
    this.createForm();
    this.getInvoiceStatusList();
  }

  createForm() {
    this.invoiceSearchForm = this.formBuilder.group({
      psuid: [],
      controlNumber: [],
      invoiceId: [],
      triad: [],
      status: [],
      fromDate: [],
      toDate: []
    });
  }
  displayInvoice() {
    this.invoiceService.getAllInvoices().subscribe((data: IInvoiceResponse[]) => {
      if(!data) {
        this.showLoader = true;
      } else {
        this.showLoader = false;
        this.invoiceTableData = data;
      }

    });
  }

  searchInvoice() {
    this.invoiceService.searchInvoice(this.invoiceSearchForm.value).subscribe((data: IInvoiceSearchResponse) => {
      if(!data) {
        this.showLoader = true;
      } else {
        this.showLoader = false;
        this.invoiceTableData = data.responseObject;
      }
    });
  }

  getInvoiceStatusList() {
    this.invoiceService.getInvoiceStatusList().subscribe((data) => {
      this.invoiceStatusList = Object.keys(data).map(key => ({ key, value: data[key] })); 
    });
  }

  openModalWithComponent(item: IInvoiceResponse) {
    this.invoiceService.getAdditionalDetails(item.invoiceSeqId).subscribe((data: IAdditionalInvoiceResponse) => {
      const initialState = {
        additionalDetails: data,
        basicDetails: item
      };
      this.bsModalRef = this.modalService.show(ViewInvoiceModalComponent, {initialState});
      this.bsModalRef.content.closeBtnName = 'Close';
    });
  }
}
