import { Component } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { IInvoiceResponse, IAdditionalInvoiceResponse } from '../../../../models/invoice.model';

@Component({
  selector: 'aba-view-invoice-modal',
  templateUrl: './view-invoice-modal.component.html',
  styleUrls: ['./view-invoice-modal.component.css']
})
export class ViewInvoiceModalComponent {

  additionalDetails: IAdditionalInvoiceResponse;
  basicDetails: IInvoiceResponse;
  constructor(public bsModalRef: BsModalRef) { }

}
