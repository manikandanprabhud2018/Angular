import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BillPackageComponent } from './bill-package.component';

describe('BillPackageComponent', () => {
  let component: BillPackageComponent;
  let fixture: ComponentFixture<BillPackageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillPackageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillPackageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
