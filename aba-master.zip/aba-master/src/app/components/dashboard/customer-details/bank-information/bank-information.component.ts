import { Component, Input } from '@angular/core';
import { ISingleBankDetails, IBankDetails, IBankBillPackageDetails } from '../../../../models/customer.model';

@Component({
  selector: 'aba-bank-information',
  templateUrl: './bank-information.component.html',
  styleUrls: ['./bank-information.component.css']
})
export class BankInformationComponent {

  @Input() bankDetails: ISingleBankDetails;
  @Input() billPackageDetails: IBankBillPackageDetails[];

}
