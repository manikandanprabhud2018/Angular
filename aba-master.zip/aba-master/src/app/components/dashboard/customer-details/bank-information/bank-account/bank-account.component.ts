import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { FormGroup , FormBuilder } from '@angular/forms';
import { ISingleBankDetails, IBankDetails, IBankBillPackageDetails } from '../../../../../models/customer.model';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { CustomerService } from '../../../../../services/customer/customer.service';

@Component({
  selector: 'aba-bank-account',
  templateUrl: './bank-account.component.html',
  styleUrls: ['./bank-account.component.css']
})
export class BankAccountComponent implements OnInit {

  editForm: FormGroup;
  singleBankDetails: IBankDetails;
  initialBankDetails: IBankDetails;
  @ViewChild(ModalDirective) bankModal: ModalDirective;
  @Input() bankDetails: ISingleBankDetails;
  bankListTableData: IBankDetails[];
  accountTypeList: any[] = [];
  constructor(
    private customerService: CustomerService,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.bankListTableData = this.bankDetails.responseObject;
    this.getDropDownValues();
    this.createForm();
  }

  getDropDownValues() {
    this.getAccountTypeList();
  }

  getAccountTypeList() {
    this.customerService.getAccountTypeList().subscribe((data) => {
      this.accountTypeList = Object.keys(data).map(key => ({ key, value: data[key] })); 
    });
  }

  createForm() {
    this.editForm = this.formBuilder.group({
      bankaccBankNm: [''],
      bankaccId: [''],
      bankaccNo: [''],
      bankaccOpenedDT: [''],
      bankaccRoutingNo: [''],
      bankaccStatusId: [''],
      bankaccTypeId:[''],
      bankaccValidtnId: [''],
      custId: ['']
    });
  }

  updateForm() {
    this.initialBankDetails = this.singleBankDetails;
    this.editForm = this.formBuilder.group({
      bankaccBankNm: [this.singleBankDetails.bankaccBankNm],
      bankaccId: [this.singleBankDetails.bankaccId],
      bankaccNo: [this.singleBankDetails.bankaccNo],
      bankaccOpenedDT: [this.singleBankDetails.bankaccOpenedDT],
      bankaccRoutingNo: [this.singleBankDetails.bankaccRoutingNo],
      bankaccStatusId: [this.singleBankDetails.bankaccStatusId],
      bankaccTypeId:[this.singleBankDetails.bankaccTypeId],
      bankaccValidtnId: [this.singleBankDetails.bankaccValidtnId],
      custId: [this.singleBankDetails.custId]
    });
  }

  showBankModal(item) {
    this.singleBankDetails = item;
    
    this.bankModal.show();
  }
  handler(type: string, $event: ModalDirective) {
    if(type === 'onShow') {
      this.updateForm();
    }
  }

  editBankDetails() {
    this.customerService.updateBankInfo(this.editForm.value).subscribe((data: any) => {
      if(data.status === 'SUCCESS') {
        this.bankListTableData = this.bankListTableData.map((item) => {
          if(JSON.stringify(item) === JSON.stringify(this.initialBankDetails)) {
            item = {
                    ...item, 
                    bankaccBankNm:data.responseObject.bankaccBankNm,
                    bankaccNo: data.responseObject.bankaccNo,
                    bankaccRoutingNo: data.responseObject.bankaccRoutingNo,
                    bankaccTypeId: data.responseObject.bankaccTypeId,
                    bankaccStatusId: data.responseObject.bankaccStatusId
                   };
          }
          return item;
        });
        this.bankModal.hide();
      }
    });
  }
}
