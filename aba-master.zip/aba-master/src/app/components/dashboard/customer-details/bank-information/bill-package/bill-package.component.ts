import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IBankBillPackageDetails } from '../../../../../models/customer.model';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { CustomerService } from '../../../../../services/customer/customer.service';

@Component({
  selector: 'aba-bill-package',
  templateUrl: './bill-package.component.html',
  styleUrls: ['./bill-package.component.css']
})
export class BillPackageComponent implements OnInit {
  
  @ViewChild(ModalDirective) billPackageModal: ModalDirective;
  @Input() billPackageDetails: IBankBillPackageDetails[];
  customerID: string;
  billPackageTableData: IBankBillPackageDetails[];
  billPackageNumbers: string[];
  bankAccountNumbers: string[];
  constructor(
    private customerService: CustomerService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.billPackageTableData = this.billPackageDetails;
    this.customerID = this.activatedRoute.snapshot.params.id;
    this.constructBillPackageNumbersArray();
    this.constructBankAccountNumbersArray();
  }

  constructBillPackageNumbersArray() {
    this.billPackageNumbers = Array.from(new Set(this.billPackageTableData.map(item =>item.billpackages)));
  }

  constructBankAccountNumbersArray() {
    this.bankAccountNumbers = this.billPackageTableData.map(item => item.bankAccountNo + ' ' + item.accountStatus);
  }

  showBillPackageModal(item: IBankBillPackageDetails) {
    this.customerService.getBillPackages(item, this.customerID).subscribe((data) => {
      this.billPackageModal.show();
    });
  }

  handler(type: string, $event: ModalDirective) {
    if(type === 'onShow') {

    }
  }

}
