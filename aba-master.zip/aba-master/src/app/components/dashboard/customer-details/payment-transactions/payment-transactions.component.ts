import { Component, OnInit, Input } from '@angular/core';
import { ISingleGraphDetails, ISingleTransactionTableDetails } from '../../../../models/customer.model';
import { FormGroup , FormBuilder } from '@angular/forms';
import { CustomerService } from '../../../../services';
import { ActivatedRoute } from '@angular/router';
import { forkJoin } from 'rxjs';
@Component({
  selector: 'aba-payment-transactions',
  templateUrl: './payment-transactions.component.html',
  styleUrls: ['./payment-transactions.component.css']
})
export class PaymentTransactionsComponent implements OnInit {

  // @Input() graphDetails: ISingleGraphDetails;
  @Input() graphDetails: any;
  // @Input() transactionTableDetails: ISingleTransactionTableDetails[];
  // transactionTableData: ISingleTransactionTableDetails[];
  @Input() transactionTableDetails: any;
  transactionTableData: any;
  fromDate: Date = new Date();
  customerID: string;
  //Chart 1
  totalPaid: number;
  outstanding: number;
  showChart1: boolean = false;
  //Chart 2
  adminFee: number;
  stoploss: number;
  claim: number;
  trf: number;
  showChart2: boolean = false;
  //Chart 3
  claimPaid: number;
  claimBalance: number;
  showChart3: boolean = false;

  //Table
  showTable: boolean = false;
  dateForm: FormGroup;


  constructor(
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private customerService: CustomerService
  ) { }

  chart1Labels:string[] = ['Total Paid', 'Outstanding Balance'];
  chart1Data:number[] = [];
  chart1Type:string = 'doughnut';

  chart2Labels:string[] = ['Admin Fee', 'Stop Loss', 'Claim', 'TRF'];
  chart2Data:number[] = [];
  chart2Type:string = 'pie';

  chart3Labels:string[] = ['Claim Paid', 'Claim Balance'];
  chart3Data:number[] = [];
  chart3Type:string = 'doughnut';

  ngOnInit() {
    this.transactionTableData = this.transactionTableDetails;
    this.showTable = this.transactionTableData.length > 0 ? true: false;
    this.createForm();
    this.constructCharts();
    this.fromDate.setFullYear(this.fromDate.getFullYear() - 1);
    this.onChanges();
    this.customerID = this.activatedRoute.snapshot.params.id;
  }

  onChanges(): void {
    this.dateForm.valueChanges.subscribe(data => {
      return forkJoin([
        this.customerService.getSingleCustomerGraphDetails(this.customerID, 'component', data),
        this.customerService.getSingleCustomerTransactionTableDetails(this.customerID, 'component', data)
      ]).subscribe((data) => {
        console.log(data);
        this.graphDetails = data[0];
        this.transactionTableData = data[1];
        this.showTable = this.transactionTableData.length > 0 ? true: false;
        this.constructCharts();
      })
    });
  }
  constructCharts() {
    this.constructChart1();
    this.constructChart2();
    this.constructChart3();
  }
  constructChart1() {
    this.totalPaid = this.graphDetails ? Number(this.graphDetails.totalInvoiceAmount) : 0;
    this.outstanding = this.graphDetails ? Number(this.graphDetails.outofBalance) : 0;
    this.showChart1 = (this.totalPaid + this.outstanding) > 0 ? true : false;
    this.chart1Data = [this.totalPaid, this.outstanding];
  }
  constructChart2() {
    this.adminFee = this.graphDetails ? Number(this.graphDetails.adminFee) : 0;
    this.stoploss = this.graphDetails ? Number(this.graphDetails.stopLossFee) : 0;
    this.claim = this.graphDetails ? Number(this.graphDetails.claimTotal) : 0;
    this.trf = this.graphDetails ? Number(this.graphDetails.trf) : 0;
    this.showChart2 = (this.adminFee + this.stoploss + this.claim + this.trf) > 0 ? true : false;
    this.chart2Data = [this.adminFee,this.stoploss,this.claim,this.trf];
  }
  constructChart3() {
    this.claimPaid = this.graphDetails ? Number(this.graphDetails.claimPaid) : 0;
    this.claimBalance = this.graphDetails ? Number(this.graphDetails.claim) : 0;
    this.showChart3 = (this.claimPaid + this.claimBalance) > 0 ? true : false;
    this.chart3Data = [this.claimPaid,this.claimBalance];
  }
  createForm() {
    this.dateForm = this.formBuilder.group({
      fromDate: this.fromDate,
      toDate: new Date()
    });
  }

}
