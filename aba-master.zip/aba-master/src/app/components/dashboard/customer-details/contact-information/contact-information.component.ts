import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ISingleContactDetails } from '../../../../models/customer.model';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';
import * as _ from 'lodash';
import { CustomerService } from '../../../../services';

@Component({
  selector: 'aba-contact-information',
  templateUrl: './contact-information.component.html',
  styleUrls: ['./contact-information.component.css']
})
export class ContactInformationComponent implements OnInit {

  constructor(
    private formBuilder: FormBuilder, 
    private customerService: CustomerService,
    private activatedRoute: ActivatedRoute) { }

  customerID: string;
  contactForm: FormGroup;
  @Input() contactDetails: ISingleContactDetails[];
  clientManagerFormData: ISingleContactDetails[];
  billingFormData: ISingleContactDetails[];
  bankingFormData: ISingleContactDetails[];
  contact1FormData: ISingleContactDetails[];
  contact2FormData: ISingleContactDetails[];
  
  disableClientManager: boolean = true;
  disableBillingContact: boolean = true;
  disableBankingContact: boolean = true;
  disableContact1: boolean = true;
  disableContact2: boolean = true;

  disableBankingDelete: boolean = true;
  disableBillingDelete: boolean = true;

  showSaveCancelButtons: boolean = false;

  ngOnInit() {
    this.customerID = this.activatedRoute.snapshot.params.id;
    this.clientManagerFormData = this.contactDetails.filter((item) => {
      return item.custcontypeId === 26;
    });
    this.billingFormData = this.contactDetails.filter((item) => {
      return item.custcontypeId === 63;
    });
    this.bankingFormData = this.contactDetails.filter((item) => {
      return item.custcontypeId === 78;
    });
    this.contact1FormData = this.contactDetails.filter((item) => {
      return item.custcontypeId === 28;
    });
    this.contact2FormData = this.contactDetails.filter((item) => {
      return item.custcontypeId === 29;
    });
    this.createForm();
  }
  createForm() {
    this.contactForm = this.formBuilder.group({
      clientManager: this.formBuilder.array(
        this.clientManagerForm()
      ),
      bankingContact: this.formBuilder.array(
        this.bankingContactForm()
      ),
      billingContact: this.formBuilder.array(
        this.billingContactForm()
      ),
      contact1: this.formBuilder.array(
        this.contact1Form()
      ),
      contact2: this.formBuilder.array(
        this.contact2Form()
      )
    });
    // this.disableBankingDelete = this.contactForm.getRawValue().bankingContact.length === 1 ? true: false;
  }

  private getEmptyRow(id) {
    const array: FormGroup[] = [];
    const formGroup: FormGroup = this.formBuilder.group({
      custId: Number(this.customerID),
      custconId: -999,
      custcontypeId: String(id),
      custconFirstNm: '',
      custconLastNm: '',
      custconemailTxt: '',
      custconphoneNo: ''
    });
    array.push(formGroup);
    return array;
  }

  clientManagerForm(): FormGroup[] {
    if(this.clientManagerFormData.length === 0) {
      const array: FormGroup[] = this.getEmptyRow(26);
      return array;
    } else {
      return this.clientManagerFormData.map((item) => {
        return this.formBuilder.group({
          custId: item.custId,
          custconId: item.custconId,
          custcontypeId: item.custcontypeId,
          custconFirstNm: item.custconFirstNm,
          custconLastNm: item.custconLastNm,
          custconemailTxt: item.custconemailTxt,
          custconphoneNo: item.custconphoneNo
        });
      });
    }
  }

  bankingContactForm(): FormGroup[] {
    if(this.bankingFormData.length === 0) {
      const array: FormGroup[] = this.getEmptyRow(78);
      return array;
    } else {
      return this.bankingFormData.map((item) => {
        return this.formBuilder.group({
          custId: item.custId,
          custconId: item.custconId,
          custcontypeId: item.custcontypeId,
          custconFirstNm: item.custconFirstNm,
          custconLastNm: item.custconLastNm,
          custconemailTxt: item.custconemailTxt,
          custconphoneNo: item.custconphoneNo
        });
      });
    }
  }

  billingContactForm(): FormGroup[] {
    if(this.billingFormData.length === 0) {
      const array: FormGroup[] = this.getEmptyRow(63);
      return array;
    } else { 
      return this.billingFormData.map((item) => {
        return this.formBuilder.group({
          custId: item.custId,
          custconId: item.custconId,
          custcontypeId: item.custcontypeId,
          custconFirstNm: item.custconFirstNm,
          custconLastNm: item.custconLastNm,
          custconemailTxt: item.custconemailTxt,
          custconphoneNo: item.custconphoneNo
        });
      });
    }
  }

  contact1Form(): FormGroup[] {
    if(this.contact1FormData.length === 0) {
      const array: FormGroup[] = this.getEmptyRow(28);
      return array;
    } else { 
      return this.contact1FormData.map((item) => {
        return this.formBuilder.group({
          custId: item.custId,
          custconId: item.custconId,
          custcontypeId: item.custcontypeId,
          custconFirstNm: item.custconFirstNm,
          custconLastNm: item.custconLastNm,
          custconemailTxt: item.custconemailTxt,
          custconphoneNo: item.custconphoneNo
        });
      });
    }
  }

  contact2Form(): FormGroup[] {
    if(this.contact2FormData.length === 0) {
      const array: FormGroup[] = this.getEmptyRow(29);
      return array;
    } else { 
      return this.contact2FormData.map((item) => {
        return this.formBuilder.group({
          custId: item.custId,
          custconId: item.custconId,
          custcontypeId: item.custcontypeId,
          custconFirstNm: item.custconFirstNm,
          custconLastNm: item.custconLastNm,
          custconemailTxt: item.custconemailTxt,
          custconphoneNo: item.custconphoneNo
        });
      });
    }
  }

  addBankingData() {
    const control: FormArray = <FormArray>this.contactForm.controls['bankingContact'];
    control.push(this.formBuilder.group({
        custId: [this.contactDetails[0].custId],
        custcontypeId:[78],
        custconFirstNm: [],
        custconLastNm: [],
        custconemailTxt: [],
        custconphoneNo: [],
        custconId: -999
    }));
    this.disableBankingDelete = control.length > 1 ? false : true;
  }

  addBillingData() {
    const control: FormArray = <FormArray>this.contactForm.controls['billingContact'];
    control.push(this.formBuilder.group({
        custId: [this.contactDetails[0].custId],
        custcontypeId:[63],
        custconFirstNm: [],
        custconLastNm: [],
        custconemailTxt: [],
        custconphoneNo: [],
        custconId: -999
    }));
    this.disableBillingDelete = control.length > 1 ? false : true;
  }

  removeBankingContact(i) {
    const control: FormArray = <FormArray>this.contactForm.controls['bankingContact'];
    control.removeAt(i);
    this.disableBankingDelete = control.length > 1 ? false : true;
  }

  removeBillingContact(i) {
    const control: FormArray = <FormArray>this.contactForm.controls['billingContact'];
    control.removeAt(i);
    this.disableBillingDelete = control.length > 1 ? false : true;
  }
  editClientManager() {
    this.disableClientManager = false;
    this.showSaveCancelButtons = true;
  }

  editBankingContact() {
    this.disableBankingDelete = this.contactForm.getRawValue().bankingContact.length > 1 ? false: true;
    this.disableBankingContact = false;
    this.showSaveCancelButtons = true;
  }

  editBillingContact() {
    this.disableBillingDelete = this.contactForm.getRawValue().billingContact.length > 1 ? false: true;
    this.disableBillingContact = false;
    this.showSaveCancelButtons = true;
  }

  editContact1() {
    this.disableContact1 = false;
    this.showSaveCancelButtons = true;
  }

  editContact2() {
    this.disableContact2 = false;
    this.showSaveCancelButtons = true;
  }

  onCancel() {
    this.disableClientManager= true;
    this.disableBillingContact= true;
    this.disableBankingContact= true;
    this.disableContact1= true;
    this.disableContact2= true;
    this.showSaveCancelButtons = false;
    this.disableBankingDelete = true;
    this.disableBillingDelete = true;
  }
  onSave() {
    let getClientContacts = [];
    let getBillingContacts = [];
    let getBankingContacts = [];
    let getContact1 = [];
    let getContact2 = [];
    let contacts = [];
    getClientContacts = this.contactForm.getRawValue().clientManager.map((item) => {
      return {
        custId: Number(item.custId),
        custconFirstNm: item.custconFirstNm,
        custconId: Number(item.custconId),
        custconemailTxt: item.custconemailTxt,
        custconphoneNo: item.custconphoneNo,
        custcontypeId: Number(item.custcontypeId)
      }
    });
    getBillingContacts = this.contactForm.getRawValue().billingContact.map((item) => {
      return {
        custId: Number(item.custId),
        custconFirstNm: item.custconFirstNm,
        custconId: Number(item.custconId),
        custconemailTxt: item.custconemailTxt,
        custconphoneNo: item.custconphoneNo,
        custcontypeId: Number(item.custcontypeId)
      }
    });
    getBankingContacts = this.contactForm.getRawValue().bankingContact.map((item) => {
      return {
        custId: Number(item.custId),
        custconFirstNm: item.custconFirstNm,
        custconId: Number(item.custconId),
        custconemailTxt: item.custconemailTxt,
        custconphoneNo: item.custconphoneNo,
        custcontypeId: Number(item.custcontypeId)
      }
    });
    getContact1 = this.contactForm.getRawValue().contact1.map((item) => {
      return {
        custId: Number(item.custId),
        custconFirstNm: item.custconFirstNm,
        custconId: Number(item.custconId),
        custconemailTxt: item.custconemailTxt,
        custconphoneNo: item.custconphoneNo,
        custcontypeId: Number(item.custcontypeId)
      }
    });
    getContact2 = this.contactForm.getRawValue().contact2.map((item) => {
      return {
        custId: Number(item.custId),
        custconFirstNm: item.custconFirstNm,
        custconId: Number(item.custconId),
        custconemailTxt: item.custconemailTxt,
        custconphoneNo: item.custconphoneNo,
        custcontypeId: Number(item.custcontypeId)
      }
    });
    contacts = [
      ...getClientContacts,
      ...getBillingContacts,
      ...getBankingContacts,
      ...getContact1,
      ...getContact2
    ];
    console.log('contacts -> ',contacts);
    this.customerService.updateContact(contacts).subscribe((data) => {
      console.log(data);
    });
  }
}
