import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup , FormArray , FormBuilder } from '@angular/forms';
import { ISinglePaymentPlan, ISingleInvoiceDetails, ISingleBankDetails, IBankBillPackageDetails } from '../../../../models/customer.model';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { CustomerService } from '../../../../services';
import { ISavePaymentReqObj } from '../../../../models/invoice.model';
import { toMMDDYYYY } from '../../../../utils/date-formatter.util';
import { subscribeOn } from 'rxjs/operators';

@Component({
  selector: 'aba-payment-plans',
  templateUrl: './payment-plans.component.html',
  styleUrls: ['./payment-plans.component.css']
})
export class PaymentPlansComponent implements OnInit {

  @Input() paymentPlanDetails: ISinglePaymentPlan[];
  @Input() invoiceDetails: ISingleInvoiceDetails;
  @Input() bankDetails: ISingleBankDetails;
  @Input() billPackageDetails: IBankBillPackageDetails[];
  paymentPlanTypeList: any[] = [];
  paymentPlanTableData: ISinglePaymentPlan[];
  invoiceAmount:number;
  invoiceDueDate: string;
  bankaccountNumberList: string[];
  billPackageNumberList: string[];
  addPaymentPlanForm: FormGroup;
  showRemove: boolean = false;
  enableSave: boolean;
  showAdd: boolean = true;
  paymentReqObj : ISavePaymentReqObj[];
  customerId: string;
  @ViewChild(ModalDirective) addPaymentPlanModal: ModalDirective;
  constructor(
    private customerService: CustomerService,
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.paymentPlanTableData = this.paymentPlanDetails;
    this.invoiceAmount = this.invoiceDetails.responseObject.length > 0 ? this.invoiceDetails.responseObject[0].invoicedueAmt : 0;
    this.invoiceDueDate = this.invoiceDetails.responseObject.length > 0 ? this.invoiceDetails.responseObject[0].invoicedueDt : '';
    this.bankaccountNumberList = this.bankDetails.responseObject.filter((item) => {
      return item.bankaccStatusId === '11'
    }).map((item) => {
      return item.bankaccNo
    });
    this.enableSave = this.invoiceAmount === 0 ? true: false;
    this.billPackageNumberList = Array.from(new Set(this.billPackageDetails.map(item =>item.billpackages)));
    this.customerId = this.activatedRoute.snapshot.params.id;
    this.getPaymentPlanTypeList();
    this.createForm();
    this.onChanges();
  }

  onChanges(): void {
    this.addPaymentPlanForm.get('paymentPlanType').valueChanges.subscribe(val => {
      if(val === '45') {
        this.showAdd = true;
        this.enableSave = this.invoiceAmount > 0 ? false : true;
      } else if(val === '46' || val == '47') {
        this.showAdd = false;
        this.enableSave = this.invoiceAmount > 0 ? false : true;
      } else if(val === '48') {
        this.showAdd = false;
        this.enableSave = false;
      }
      this.resetPaymentArray();
    });
  }

  resetPaymentArray() {
    const control: FormArray = <FormArray>this.addPaymentPlanForm.controls['payment'];
    while(control.length > 0) {
      control.removeAt(0);
    }
    control.push(this.formBuilder.group({
      paymentDueDate: [],
      amount: [],
      percentage: [],
      reason: []
    }));
    this.showRemove = control.length >= 2 ? true: false;
  }
  createForm() {
    this.addPaymentPlanForm = this.formBuilder.group({
      billPackage: [],
      invoiceDueDate: [this.invoiceDueDate],
      invoiceAmount: [this.invoiceAmount],
      bankAccount: [],
      paymentPlanType: ['45'],
      payment: this.formBuilder.array([ this.getPaymentFormGroup() ])
    });
  }

  getPaymentFormGroup() : FormGroup {
    return this.formBuilder.group({
      paymentDueDate: [],
      amount: [],
      percentage: [],
      reason: []
    })
  }

  addPaymentRow() {
    const control: FormArray = <FormArray>this.addPaymentPlanForm.controls['payment'];
    this.showRemove = control.length > 0 ? true: false;
    control.push(this.formBuilder.group({
      paymentDueDate: [],
      amount: [],
      percentage: [],
      reason: []
    }));
  }

  removePaymentRow(i) {
    const control: FormArray = <FormArray>this.addPaymentPlanForm.controls['payment'];
    this.showRemove = control.length === 2 ? false: true;
    control.removeAt(i);
  }

  savePlan() {
    this.paymentReqObj = this.addPaymentPlanForm.value.payment.map((item) => {
      return {
        amount: item.amount,
        custpppaymentAmt: item.amount,
        custpppaymentPct: item.percentage,
        custppreasonTxt: item.reason,
        custId: this.customerId,
        bacckAccNo: this.addPaymentPlanForm.get('bankAccount').value,
        custbpId: this.addPaymentPlanForm.get('billPackage').value,
        custppeffDt: this.invoiceDueDate,
        custpppayptypId: this.addPaymentPlanForm.get('paymentPlanType').value,
        custppexpDt: toMMDDYYYY(item.paymentDueDate)
      }
    });
    this.customerService.addPaymentPlan(this.paymentReqObj).subscribe((data: any) => {
      if(data.status === 'SUCCESS') {
        this.paymentPlanTableData.push(...this.paymentReqObj);
        this.addPaymentPlanModal.hide();
      }
    });
  }

  removePaymentPlan(item: ISinglePaymentPlan) {
    this.customerService.removePaymentPlan(item).subscribe((data: string) => {
      if(data === 'Successfully deleted the payment plan') {
        alert('Payment has been removed');
        this.paymentPlanTableData = this.paymentPlanTableData.filter((plan) => {
          return plan.custppId !== item.custppId;
        });
      }
    });
  }
  getPaymentPlanTypeList() {
    this.customerService.getPaymentPlanTypeList().subscribe((data) => {
      this.paymentPlanTypeList = Object.keys(data).map(key => ({ key, value: data[key] }));
    });
  }

  showAddPaymentModal() {    
    this.addPaymentPlanModal.show();
  }

  handler(type: string, $event: ModalDirective) {
    if(type === 'onShow') {
    }
  }
}
