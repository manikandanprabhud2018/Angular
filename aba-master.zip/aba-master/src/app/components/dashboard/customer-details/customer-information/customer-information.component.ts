import { Component, Input, OnInit } from '@angular/core';
import { ISingleCustomerDetails, ISingleSecondaryCustomerDetails } from '../../../../models/customer.model';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CustomerService } from '../../../../services/customer/customer.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'aba-customer-information',
  templateUrl: './customer-information.component.html',
  styleUrls: ['./customer-information.component.css']
})
export class CustomerInformationComponent implements OnInit {

  loadForm: boolean = false;
  tpaList: any[] = [];
  paymentTypeList: any[] = [];
  paymentDueDateList: any[] = [];
  holdReasonList: any[] = [];
  billPackageList: string[] = [];
  customerInfoForm: FormGroup;
  editable:boolean = false;
  lateFeeStatus: boolean;
  holdStatus: boolean;
  showHoldReason: boolean;
  showLateFeeTextbox: boolean;
  editLateFee: boolean = false;
  message: string;
  constructor(
    private formBuilder: FormBuilder,
    private customerService: CustomerService,
    private activatedRoute: ActivatedRoute,
  ) { }

  @Input() customerDetails: ISingleCustomerDetails;
  @Input() billPackageIDs: string[];
  customerSecondaryDetails: ISingleSecondaryCustomerDetails;
  ngOnInit() {
    this.loadForm = false;
    this.getDropDownValues();
    this.getSecondaryDetails();
    this.billPackageList = this.billPackageIDs;
    this.showLateFeeTextbox = (this.customerDetails.latefeeAmnt === 'N/A' || this.customerDetails.latefeeAmnt === 'NA' || this.customerDetails.latefeeAmnt === null) ? false : true;
    this.lateFeeStatus = (this.customerDetails.latefeeInd === 'N' || this.customerDetails.latefeeInd === null) ? false : true; 
    this.holdStatus = this.showHoldReason = this.customerDetails.hold === 'H' ? true : false;
  }

  onChange() {
    this.customerInfoForm.get('billPackage').valueChanges.subscribe((billPackageID) => {
      console.log('form value changed!');
      this.loadForm = false;
      this.customerService.getSingleCustomerSecondaryDetails(this.activatedRoute.snapshot.params.id,billPackageID).subscribe((data) => {
        console.log('Service call made!');
        this.customerSecondaryDetails = data;
        this.loadForm = true;
        this.createForm();
      });
    });
  }
  getDropDownValues() {
    this.getTPAList();
    this.getPaymentTypeList();
    this.getPaymentDueDateList();
    this.getHoldReasonList();
  }

  getSecondaryDetails() {
    this.customerService.getSingleCustomerSecondaryDetails(this.activatedRoute.snapshot.params.id,this.customerDetails.billPackage).subscribe((data) => {
      this.customerSecondaryDetails = data;
      this.loadForm = true;
      this.createForm();
      this.onChange();
    });
  }

  createForm() {
      this.customerInfoForm = this.formBuilder.group({
        state: [this.customerDetails.state],
        paymentType: [this.customerDetails.paymentTypeId],
        paymentDueDate: [this.customerDetails.paymentDueDateId],
        tpaName: [this.customerDetails.tpaNameId],
        cbi: [this.customerSecondaryDetails.customerBillIndicator ? this.customerSecondaryDetails.customerBillIndicator : ''],
        triad: [this.customerSecondaryDetails.traidCode],
        filenetID: [this.customerDetails.filenetId],
        billPackage: [this.customerDetails.billPackage],
        emailID: [this.customerSecondaryDetails.billpackageEmailId],
        phone: [this.customerSecondaryDetails.phoneNumber],
        orgName: [this.customerSecondaryDetails.orgTypeCode],
        cfo:[this.customerSecondaryDetails.cfo],
        lateFeeInd: [this.customerDetails.latefeeInd],
        lateFeeAmount: [this.customerSecondaryDetails.latefeeAmount ? this.customerSecondaryDetails.latefeeAmount: 'N/A'],
        holdInd: [this.customerDetails.hold],
        holdReason: [this.customerDetails.holdReason],
        uwMarginAdjustment: [this.customerSecondaryDetails.umaAmount],
        wirelineNumber: [this.customerDetails.claimsWirelineNumber],
        terminationDate: [this.customerDetails.terminationDate],
        subStatus: [this.customerSecondaryDetails.customerSubStatus]
      });
  }

  getTPAList() {
    this.customerService.getTPAList().subscribe((data) => {
      this.tpaList = Object.keys(data).map(key => ({ key, value: data[key] }));
    });
  }

  getPaymentTypeList() {
    this.customerService.getPaymentTypeList().subscribe((data) => {
      this.paymentTypeList = Object.keys(data).map(key => ({ key, value: data[key] }));
    });
  }

  getPaymentDueDateList() {
    this.customerService.getPaymentDueDateList().subscribe((data) => {
      this.paymentDueDateList = Object.keys(data).map(key => ({ key, value: data[key] }));
    });
  }

  getHoldReasonList() {
    this.customerService.getHoldReasonList().subscribe((data) => {
      this.holdReasonList = Object.keys(data).map(key => ({ key, value: data[key] }));
    });
  }

  setLateFeeStatus(value) {
    if(value) {
      this.customerInfoForm.patchValue({
        lateFeeInd: 'Y'
      });
    } else {
      this.customerInfoForm.patchValue({
        lateFeeInd: 'N'
      });
    }
  }

  setHoldStatus(value) {
    if(value) {
      this.showHoldReason = true;
      this.customerInfoForm.patchValue({
        holdInd: 'H'
      });
    } else {
      this.showHoldReason = false;
      this.customerInfoForm.patchValue({
        holdInd: '',
        holdReason: null
      });
    }
  }

  toggleEditLateFee() {
   this.editLateFee = !this.editLateFee; 
  }
  onEdit() {
    this.editable = true;
    if(this.editable) {
      this.editLateFee = false;
    } else if(!this.editLateFee){
      this.editLateFee = false;
    }
  }

  onSave() {
    let lateFee = this.customerInfoForm.get('lateFeeAmount').value;
    this.customerService.updateCustomerInfo(this.customerInfoForm.value, this.customerDetails, lateFee).subscribe((data: any) => {
      if(data.status === 'SUCCESS') {
        this.message = 'Saved Successfully!';
      } else {
        this.message = 'Error'
      }
    });
    this.editable = false;
    if(this.editable) {
      this.editLateFee = false;
    }
  }

  onCancel() {
    this.createForm();
    this.editLateFee = false;
    this.editable = false;
    if(this.editable) {
      this.editLateFee = false;
    }
  }
}
