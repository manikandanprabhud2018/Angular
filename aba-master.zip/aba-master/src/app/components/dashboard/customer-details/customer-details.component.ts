import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ISingleCustomerDetails, ISingleBankDetails, ISingleContactDetails, ISingleNotesDetails, IBankBillPackageDetails, ISinglePaymentPlan, ISingleInvoiceDetails, ISingleGraphDetails, ISingleTransactionTableDetails } from '../../../models/customer.model';

@Component({
  selector: 'aba-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {

  customerDetails: ISingleCustomerDetails;
  bankDetails: ISingleBankDetails;
  contactDetails: ISingleContactDetails[];
  notesDetails: ISingleNotesDetails[];
  billPackageDetails: IBankBillPackageDetails[];
  paymentPlanDetails: ISinglePaymentPlan[];
  invoiceDetails: ISingleInvoiceDetails;
  graphDetails: ISingleGraphDetails;
  transactionTableDetails: ISingleTransactionTableDetails[];
  billPackageIDs: string[];
  constructor(private activatedRoute: ActivatedRoute) { }
  ngOnInit() {
    this.customerDetails = this.activatedRoute.snapshot.data.singleCustomerData[0];
    this.bankDetails = this.activatedRoute.snapshot.data.singleCustomerData[1];
    this.contactDetails = this.activatedRoute.snapshot.data.singleCustomerData[2];
    this.notesDetails = this.activatedRoute.snapshot.data.singleCustomerData[3];
    this.billPackageDetails = this.activatedRoute.snapshot.data.singleCustomerData[4];
    this.paymentPlanDetails = this.activatedRoute.snapshot.data.singleCustomerData[5];
    this.invoiceDetails = this.activatedRoute.snapshot.data.singleCustomerData[6];
    this.graphDetails = this.activatedRoute.snapshot.data.singleCustomerData[7];
    this.transactionTableDetails = this.activatedRoute.snapshot.data.singleCustomerData[8];
    this.billPackageIDs = this.activatedRoute.snapshot.data.singleCustomerData[9];
  }

}
