import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ISingleInvoiceDetails } from '../../../../models/customer.model';
import { IInvoiceResponse, IAdditionalInvoiceResponse } from '../../../../models/invoice.model';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { InvoiceService } from '../../../../services/invoice/invoice.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'aba-invoice-details',
  templateUrl: './invoice-details.component.html',
  styleUrls: ['./invoice-details.component.css']
})
export class InvoiceDetailsComponent implements OnInit {

  @Input() invoiceDetails: ISingleInvoiceDetails;
  invoiceTableData: any;
  customerID: string;
  additionalInvoice: IAdditionalInvoiceResponse;
  @ViewChild(ModalDirective) invoiceModal: ModalDirective;
  constructor(
    private invoiceService: InvoiceService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.invoiceTableData = this.invoiceDetails.responseObject;
    this.customerID = this.activatedRoute.snapshot.params.id;
    this.invoiceService.getAdditionalDetails(this.customerID).subscribe((data: IAdditionalInvoiceResponse) => {
      this.additionalInvoice = data;
    });
  }

  showInvoiceModal() {
    this.invoiceModal.show();
  }

}
