import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { FormGroup , FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ISingleNotesDetails } from '../../../../models/customer.model';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { CustomerService } from '../../../../services/customer/customer.service';
import { toHHMMSSFormat } from '../../../../utils/date-formatter.util';

@Component({
  selector: 'aba-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.css']
})
export class NotesComponent implements OnInit {

  constructor(
    private customerService: CustomerService,
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute
  ) { }
  addNotesForm: FormGroup;
  @Input() notesDetails: ISingleNotesDetails[];
  customerID: string;
  notesTableData: ISingleNotesDetails[];
  @ViewChild(ModalDirective) notesModal: ModalDirective;

  ngOnInit() {
    this.notesTableData = this.notesDetails;
    this.customerID = this.activatedRoute.snapshot.params.id;
    this.createForm();
  }

  createForm() {
    this.addNotesForm = this.formBuilder.group({
      notes: ['', Validators.required],
      notesTimestamp: [new Date()]
    });
  }

  showAddNotesModal() {
    this.notesModal.show();
  }

  handler(type: string, $event: ModalDirective) {
    if(type === 'onShow') {
    }
  }

  addNotes() {
    let notesData = {
      custId: this.customerID,
      custnoteTxt: this.addNotesForm.value.notes,
      custnotecreateDts: toHHMMSSFormat(this.addNotesForm.value.notesTimestamp),
      custnoteuserId: 'N271673'
    };
    this.customerService.addNotes(notesData).subscribe((data: any) => {
      if(data.status === 'SUCCESS') {
        this.notesTableData.push({
          custId: Number(this.customerID),
          custnoteId: 0,
          custnoteTxt: this.addNotesForm.value.notes,
          custnotecreateDts: toHHMMSSFormat(this.addNotesForm.value.notesTimestamp),
          custnoteuserId: 'N271673'
        });
        this.notesModal.hide();
      }
    });
  }
}
