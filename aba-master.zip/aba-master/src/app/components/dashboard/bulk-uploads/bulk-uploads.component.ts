import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import { BulkUploadsService } from '../../../services';
@Component({
  selector: 'app-bulk-uploads',
  templateUrl: './bulk-uploads.component.html',
  styleUrls: ['./bulk-uploads.component.css']
})
export class BulkUploadsComponent implements OnInit {
  data: any;
  valid: boolean = true;
  constructor(private bulkUploadsService: BulkUploadsService) { }
  ngOnInit() {
  }
  /* onFileChange(evt: any) {
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, {type: 'binary'});
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];
      this.data = XLSX.utils.sheet_to_json(ws);
      this.valid = this.data.length < 5000 ? false : true;
    };
    reader.readAsBinaryString(target.files[0]);
    this.bulkUploadsService.uploadCustomerExcel(target.files[0]).subscribe((data) => {
      console.log('File Upload Result', data);
    });
  } */
  onFileChange(evt: any) {
    const target: DataTransfer = <DataTransfer>(evt.target);
    this.bulkUploadsService.uploadCustomerExcel(target.files[0]).subscribe((data) => {
      console.log('File Upload Result', data);
    });
  }
  

}
