import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CustomerService } from '../../../services/customer/customer.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ISearchResponse, ICustomer } from '../../../models/customer.model';
@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  constructor(
      private customerService: CustomerService,
      private formBuilder: FormBuilder,
      private router: Router,
      private activatedRoute: ActivatedRoute
  ) { }

  showAddCustomer: boolean = false;
  customerSearchForm: FormGroup;
  customerTableData: ICustomer[];
  customerCategory: string[] = [
    'All Customer Information',
    'Missing Bank Information',
    'Missing Invoice',
    'Missing Customer Setup',
    'Missing Claims Wireline No',
    'Late Fee Customer'
  ];
  status: string[] = ['Approved', 'Pending', 'Terminated'];
  customersList: string[];
  ngOnInit() {
    this.allCustomerInfo();
    this.createForm();
    this.activatedRoute.queryParams.subscribe((data) => {
      if(data) {
        this.getCategory(data.info);
      }
    });
  }

  createForm() {
    this.customerSearchForm = this.formBuilder.group({
      customerName: '',
      psuid: '',
      controlNumber: '',
      status: '',
      effectiveDate: null,
    });
  }
  getCategory(category) {
    if(category === 'All Customer Information') {
      this.allCustomerInfo();
    } else if(category === 'Missing Bank Information') {
      this.missingBankInfo();
    } else if(category === 'Missing Invoice') {
      this.missingInvoiceInfo();
    } else if(category === 'Missing Customer Setup') {
      this.missingCustomerSetup();
    } else if(category === 'Missing Claims Wireline No') {
      this.missingClaimsWirelineInfo();
    } else if(category === 'Late Fee Customer') {
      this.lateFeeCustomer();
    }
  }
  allCustomerInfo() {
    this.customerService.getAllCustomers().subscribe((data: ICustomer[]) => {
      this.customersList = data.map((item) => {
        return item.customerName;
      });
      this.customerTableData = data;
    });
  }

  missingBankInfo() {
    this.customerService.missingBankInfo().subscribe((data: ICustomer[]) => {
      this.customerTableData = data;
    });
  }

  missingInvoiceInfo() {
    this.customerService.missingInvoiceInfo().subscribe((data: ICustomer[]) => {
      this.customerTableData = data;
    });
  }

  missingCustomerSetup() {
    this.customerService.missingCustomerSetup().subscribe((data: ICustomer[]) => {
      this.customerTableData = data;
    });
  }

  missingClaimsWirelineInfo() {
    this.customerService.missingClaimsWirelineInfo().subscribe((data: ICustomer[]) => {
      this.customerTableData = data;
    });
  }

  lateFeeCustomer() {
    this.customerService.lateFeeCustomer().subscribe((data: ICustomer[]) => {
      this.customerTableData = data;
    });
  }

  searchCustomer() {
    this.customerService.searchCustomer(this.customerSearchForm.value).subscribe((data: ISearchResponse) => {
      if(data.status == 'SUCCESS') {
        this.customerTableData = data.responseObject;
      } else {
        this.customerTableData = [{
          reason: 'No Data Found'
        }];
      }
    });
  }

  openAddCustomer() {
    this.showAddCustomer = true;
  }

  getCustomerDetails(id) {
    this.router.navigate(['/dashboard/customers', id]);
  }
}
