import { Component, TemplateRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerService } from '../../../services/customer/customer.service';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import * as _ from 'lodash';
@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  modalRef: BsModalRef;
  addCustomerForm: FormGroup;
  tpaList: any[] = [];
  paymentTypeList: any[] = [];
  paymentDueDateList: any[] = [];
  accountTypeList: any[] = [];
  @ViewChild(ModalDirective) addPaymentPlanModal: ModalDirective;
  constructor(
    private formBuilder: FormBuilder,
    private customerService: CustomerService
  ) { }

  ngOnInit() {
    this.createForm();
    this.getDropDownValues();
  }

  getDropDownValues() {
    this.getTPAList();
    this.getPaymentTypeList();
    this.getPaymentDueDateList();
    this.getAccountTypeList();
  }
  createForm() {
    const customerInfoForm: FormGroup = this.formBuilder.group({
      customerName: [],
      psuid: [],
      controlNumber: [],
      effectiveDate: new Date(),
      state: [],
      tpaName: [],
      filenetID: [],
      paymentType: [],
      paymentDueDate: [],
      wirelineNumber: []
    });
    const bankInfoForm: FormGroup = this.formBuilder.group({
      bankName: [],
      accountNumber: [],
      routingNumber: [],
      accountType: [],
      status: ['11']
    });
    const notesForm: FormGroup = this.formBuilder.group({
      notes: []
    });
    this.addCustomerForm = this.formBuilder.group({
      customerInfoForm,
      bankInfoForm,
      contactDetailsForm: this.formBuilder.array([
        this.createContactDetails1(),
        this.createContactDetails2(),
        this.createContactDetails3(),
        this.createContactDetails4(),
        this.createContactDetails5()
      ]) ,
      notesForm
    });
  }

  setBankAccountStatus(value) {
    if(value) {
      this.addCustomerForm.patchValue({
        bankInfoForm: {
          status: '11'
        }
      })
    } else {
      this.addCustomerForm.patchValue({
        bankInfoForm: {
          status: '12'
        }
      })
    }
  }
  createContactDetails1(): FormGroup {
    return this.formBuilder.group({
      role: ['Client Manager'],
      firstname: [],
      lastname: [],
      emailID: [],
      phoneNumber: []
    })
  }
  createContactDetails2(): FormGroup {
    return this.formBuilder.group({
      role: ['Billing Contact'],
      firstname: [],
      lastname: [],
      emailID: [],
      phoneNumber: []
    })
  }
  createContactDetails3(): FormGroup {
    return this.formBuilder.group({
      role: ['Banking Contact'],
      firstname: [],
      lastname: [],
      emailID: [],
      phoneNumber: []
    })
  }
  createContactDetails4(): FormGroup {
    return this.formBuilder.group({
      role: ['Contact 1'],
      firstname: [],
      lastname: [],
      emailID: [],
      phoneNumber: []
    })
  }
  createContactDetails5(): FormGroup {
    return this.formBuilder.group({
      role: ['Contact 2'],
      firstname: [],
      lastname: [],
      emailID: [],
      phoneNumber: []
    })
  }

  getTPAList() {
    this.customerService.getTPAList().subscribe((data) => {
      this.tpaList = Object.keys(data).map(key => ({ key, value: data[key] }));
    });
  }

  getPaymentTypeList() {
    this.customerService.getPaymentTypeList().subscribe((data) => {
      this.paymentTypeList = Object.keys(data).map(key => ({ key, value: data[key] }));
    });
  }

  getPaymentDueDateList() {
    this.customerService.getPaymentDueDateList().subscribe((data) => {
      this.paymentDueDateList = Object.keys(data).map(key => ({ key, value: data[key] }));
    });
  }

  getAccountTypeList() {
    this.customerService.getAccountTypeList().subscribe((data) => {
      this.accountTypeList = Object.keys(data).map(key => ({ key, value: data[key] })); 
    });
  }

  addCustomer() {
    this.customerService.addCustomer(this.addCustomerForm.value).subscribe((data: any) => {
      if(data.status === 'SUCCESS' || data.status === 'FAILURE') {
        this.addPaymentPlanModal.show();
      }
    });
  }

  handler(type: string, $event: ModalDirective) {
    if(type === 'onShow') {
    }
  }
}
