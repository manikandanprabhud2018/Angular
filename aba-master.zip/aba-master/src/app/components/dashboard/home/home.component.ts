import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HomeService, CustomerService } from '../../../services';
import { ICustomer } from '../../../models/customer.model';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  recentlyAddedCustomerList: ICustomer[];
  totalCustomers: any;
  totalLateFeeCustomers: any;
  totalMissingBankInfo: any;
  totalMissingInvoice: any;
  totalMissingCustomerSetup: any;
  totalMissingclaimWireLineNo;
  constructor(
    private homeService:HomeService,
    private customerService: CustomerService,
    private router: Router
  ) { }

  ngOnInit() {
    this.getDashboardData();
  }

  getDashboardData() {
    this.getRecentlyAddedCustomers();
    this.customerService.getAllCustomers().subscribe((data: ICustomer[]) => {
      this.totalCustomers = data ? data.length : 0;
    });
    this.customerService.lateFeeCustomer().subscribe((data: ICustomer[]) => {
      this.totalLateFeeCustomers = data ? data.length : 0;
    });
    this.customerService.missingBankInfo().subscribe((data: ICustomer[]) => {
      this.totalMissingBankInfo = data ? data.length : 0;
    });
    this.customerService.missingInvoiceInfo().subscribe((data: ICustomer[]) => {
      this.totalMissingInvoice = data ? data.length : 0;
    });
    this.customerService.missingCustomerSetup().subscribe((data: ICustomer[]) => {
      this.totalMissingCustomerSetup = data ? data.length : 0;
    });
    this.customerService.missingClaimsWirelineInfo().subscribe((data: ICustomer[]) => {
      this.totalMissingclaimWireLineNo = data ? data.length : 0;
    });
  }

  getRecentlyAddedCustomers() {
    this.homeService.getRecentlyAddedCustomers().subscribe((data: ICustomer[]) => {
      this.recentlyAddedCustomerList = data;
    });
  }

  viewCustomer(id) {
    this.router.navigate(['/dashboard/customers', id]);
  }

  viewCustomers(info) {
    this.router.navigate(['/dashboard/customers'],  { queryParams: { info:info } });
  }
}
