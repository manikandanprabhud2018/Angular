import { AbaService } from './aba-service.service';
import { CustomerService } from './customer/customer.service';
import { InvoiceService } from './invoice/invoice.service';
import { AuditLogService } from './audit-log/audit-log.service';
import { BulkUploadsService } from './bulk-uploads/bulk-uploads.service';
import { HomeService } from './home/home.service';
export const services : any[] = [
    AbaService,
    CustomerService,
    InvoiceService,
    AuditLogService,
    BulkUploadsService,
    HomeService
];

export * from './aba-service.service';
export * from './customer/customer.service';
export * from './invoice/invoice.service';
export * from './audit-log/audit-log.service';
export * from './bulk-uploads/bulk-uploads.service';
export * from './home/home.service';