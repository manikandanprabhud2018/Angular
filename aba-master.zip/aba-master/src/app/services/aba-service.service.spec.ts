import { TestBed } from '@angular/core/testing';

import { AbaServiceService } from './aba-service.service';

describe('AbaServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AbaServiceService = TestBed.get(AbaServiceService);
    expect(service).toBeTruthy();
  });
});
