import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse, HttpParams } from '@angular/common/http';
import { token } from '../../utils/token';
import * as fromApiContainer from '../../api-container';
@Injectable({
  providedIn: 'root'
})
export class HomeService {
  options = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      'Accept': 'application/json',
      'UserName': 'N271673',
      'AccessToken': token
    })
  };
  constructor(private httpClient: HttpClient) { }

  getRecentlyAddedCustomers() {
    return this.httpClient.get(fromApiContainer.GET_RECENTLY_ADDED_CUSTOMERS, this.options);
  }
}
