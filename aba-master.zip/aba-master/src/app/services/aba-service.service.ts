import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js'
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import * as fromApiContainer from '../api-container';
@Injectable({
  providedIn: 'root'
})
export class AbaService {

  constructor(private httpClient: HttpClient ) { }

  login(user) {
      var AesUtilPre = function(keySize:any, iterationCount:any) {
        this.keySize = keySize / 32;
        this.iterationCount = iterationCount;
      };
      AesUtilPre.prototype.generateKey = function(salt:any, passPhrase:any) {
        var key = CryptoJS.PBKDF2(
            passPhrase, 
            CryptoJS.enc.Hex.parse(salt),
            { keySize: this.keySize, iterations: this.iterationCount });
        return key;
      }
      
      AesUtilPre.prototype.encrypt = function(salt:any, iv:any, passPhrase:any, plainText:any) {
        var key = this.generateKey(salt, passPhrase);
        var encrypted = CryptoJS.AES.encrypt(
            plainText,
            key,
            { iv: CryptoJS.enc.Hex.parse(iv) });
        return encrypted.ciphertext.toString(CryptoJS.enc.Base64);
      }
      
      AesUtilPre.prototype.decrypt = function(salt:any, iv:any, passPhrase:any, cipherText:any) {
        var key = this.generateKey(salt, passPhrase);
        var cipherParams = CryptoJS.lib.CipherParams.create({
          ciphertext: CryptoJS.enc.Base64.parse(cipherText)
        });
        var decrypted = CryptoJS.AES.decrypt(
            cipherParams,
            key,
            { iv: CryptoJS.enc.Hex.parse(iv) });
        return decrypted.toString(CryptoJS.enc.Utf8);
      }
      
      let iv = "F27D5C9927726BCEFE7510B1BDD3D137";
      let salt = "3FF2EC019C627B945225DEBAD71A01B6985FE84C95A70EB132882F88C0A59A55";
      let keySize = 128;
      let iterationCount = 10000;
      let passPhrase = "aesalgoisbestbes";
      let aesUtil = new AesUtilPre(keySize, iterationCount);
      user.password = aesUtil.encrypt(salt, iv, passPhrase, user.password);
      
      return this.httpClient.post(fromApiContainer.LOGIN, user, {
        headers: new HttpHeaders({
          'Content-Type':  'application/json'
        }),
        observe: 'response'
      });
      /* return this.httpClient.post(this.domain, user, {
        headers: new HttpHeaders({
          'Content-Type':  'application/json'
        })
      }); */
  }
  getUserDetails() {
   /*  getInvoiceUsers(StartIndex,EndIndex){
      let reqheaders:Headers = new Headers();
         reqheaders.append("Accept","application/json");
         reqheaders.append("AccessToken",sessionStorage.getItem("accessToken"));
         reqheaders.append("UserName",sessionStorage.getItem("username"));
         let options = new RequestOptions({headers: reqheaders});
         let url = globalService.serviceUrl+"/rest/v1/customers/missingInvoices?StartIndex="+StartIndex+"&NumberOfRecords="+EndIndex;
        //return this.http.get("https://devinternal.aetna.com/abaService2/rest/customers/listAll?StartIndex="+StartIndex+"&EndIndex="+EndIndex,options)
        return this.http.get(url,options)
           //.map((res: Response) => res.json().customerList);
           .map((res: Response) => res.json());
     } */
     const options = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Accept': 'application/json',
        'UserName': 'N271673',
        'AccessToken': 'VI57B1iLMY9FAJuAwUcGcCItkFKs0l1O'
      })
    };
    // return this.httpClient.get('https://qainternal.aetna.com/abaService3/rest/customers/listAll?StartIndex=1&NumberOfRecords=10000', options);
    return this.httpClient.get('https://devinternal.aetna.com/abaService/rest/customers/listAll?StartIndex=1&NumberOfRecords=10000', options);
  }
}
