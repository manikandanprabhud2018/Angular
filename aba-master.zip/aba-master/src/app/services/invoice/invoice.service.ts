import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { IInvoiceSearchParams } from '../../models/invoice.model';
import { toMMDDYYYY } from '../../utils/date-formatter.util';
import { token } from '../../utils/token';
import * as fromApiContainer from '../../api-container';
@Injectable({
  providedIn: 'root'
})
export class InvoiceService {
  options = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      'Accept': 'application/json',
      'UserName': 'N271673',
      'AccessToken': token
    })
  };
  constructor(private httpClient: HttpClient) { }

  getAllInvoices() {
    return this.httpClient.get(fromApiContainer.GET_ALL_INVOICES, this.options);
  }

  getInvoiceStatusList() {
    let params = new HttpParams();
    params = params.append('id', '17');

    return this.httpClient.get(fromApiContainer.GET_LOOKUP_DETAILS,  {headers: this.options.headers, params});
  }
  searchInvoice(invoiceSearchParams: IInvoiceSearchParams) {
    let searchData = {
      controlNumber: invoiceSearchParams.controlNumber,
      fromEffectiveDate: invoiceSearchParams.fromDate ? toMMDDYYYY(invoiceSearchParams.fromDate) : '',
      invoiceId: invoiceSearchParams.invoiceId,
      psuid: invoiceSearchParams.psuid,
      status: invoiceSearchParams.status,
      toEffectiveDate: invoiceSearchParams.toDate ? toMMDDYYYY(invoiceSearchParams.toDate): '',
      traid: invoiceSearchParams.triad
    };
    return this.httpClient.post(fromApiContainer.SEARCH_INVOICE, searchData, this.options);
  }

  getAdditionalDetails(id) {
    return this.httpClient.get(fromApiContainer.GET_ADDITIONAL_INVOICE_DETAILS+id, this.options);
  }
}
