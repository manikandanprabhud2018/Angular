import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Observable, forkJoin } from 'rxjs';
import { CustomerService } from './customer.service';

@Injectable({
  providedIn: 'root'
})
export class CustomerResolver implements Resolve<Observable<any>> {
  constructor(
      private customerService: CustomerService
  ) { }
 
  resolve(activatedRoute: ActivatedRouteSnapshot) {
    let id: string = activatedRoute.paramMap.get('id');
    return forkJoin([
      this.customerService.getSingleCustomerDetails(id),
      this.customerService.getSingleCustomerBankDetails(id),
      this.customerService.getSingleCustomerContactDetails(id),
      this.customerService.getSingleCustomerNotesDetails(id),
      this.customerService.getSingleCustomerBillPackageDetails(id),
      this.customerService.getSingleCustomerPaymentPlanDetails(id),
      this.customerService.getSingleCustomerInvoiceDetails(id),
      this.customerService.getSingleCustomerGraphDetails(id, 'resolver'),
      this.customerService.getSingleCustomerTransactionTableDetails(id, 'resolver'),
      this.customerService.getSingleCustomerBillPackages(id)
    ])
  }
}
