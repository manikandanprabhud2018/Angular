import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse, HttpParams } from '@angular/common/http';
import { IAddCustomer, ISingleCustomerDetails, IBankBillPackageDetails, ISinglePaymentPlan } from '../../models/customer.model';
import { token } from '../../utils/token';
import { toMMDDYYYY, toMMDDYYYY1 } from '../../utils/date-formatter.util';
import * as fromApiContainer from '../../api-container';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  options = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      'Accept': 'application/json',
      'UserName': 'N271673',
      'AccessToken': token
    })
  };
  constructor(private httpClient: HttpClient) { }

  getAllCustomers() {
    return this.httpClient.get(fromApiContainer.GET_ALL_CUSTOMERS, this.options);
  }
  missingBankInfo() {
    return this.httpClient.get(fromApiContainer.GET_MISSING_BANK_INFO, this.options);
  }

  missingInvoiceInfo() {
    return this.httpClient.get(fromApiContainer.GET_MISSING_INVOICE_INFO, this.options);
  }

  missingCustomerSetup() {
    return this.httpClient.get(fromApiContainer.GET_MISSING_CUSTOMER_SETUP_INFO, this.options);
  }

  missingClaimsWirelineInfo() {
    return this.httpClient.get(fromApiContainer.GET_MISSING_CLAIMS_WIRELINE__INFO, this.options);
  }

  lateFeeCustomer() {
    return this.httpClient.get(fromApiContainer.GET_LATEFEE_CUSTOMER_INFO, this.options);
  }

  searchCustomer(searchParams) {
    let url = fromApiContainer.SEARCH_CUSTOMER;
    return this.httpClient.post(url, searchParams, this.options);
  }

  getTPAList() {

    let params = new HttpParams();
    params = params.append('id', '7');

    return this.httpClient.get(fromApiContainer.GET_LOOKUP_DETAILS, {headers:this.options.headers, params});
  }
  getPaymentTypeList() {

    let params = new HttpParams();
    params = params.append('id', '1');

    return this.httpClient.get(fromApiContainer.GET_LOOKUP_DETAILS, {headers: this.options.headers, params});
  }
  getPaymentPlanTypeList() {

    let params = new HttpParams();
    params = params.append('id', '13');

    return this.httpClient.get(fromApiContainer.GET_LOOKUP_DETAILS, {headers: this.options.headers, params});
  }

  getPaymentDueDateList() {

    let params = new HttpParams();
    params = params.append('id', '2');

    return this.httpClient.get(fromApiContainer.GET_LOOKUP_DETAILS, {headers: this.options.headers, params});
  }

  getAccountTypeList() {
    let params = new HttpParams();
    params = params.append('id', '3');

    return this.httpClient.get(fromApiContainer.GET_LOOKUP_DETAILS, {headers: this.options.headers, params});
  }

  getHoldReasonList() {
    let params = new HttpParams();
    params = params.append('id', '20');

    return this.httpClient.get(fromApiContainer.GET_LOOKUP_DETAILS, {headers: this.options.headers, params});
  }

  formateDate(date): string {
    return (date.getMonth() + 1) + '/' + date.getDate() + '/' +  date.getFullYear();
  }

  notesSaveTimestamp(): string {
    const d: Date = new Date();
    let formattedDate: string = 
        d.getFullYear() + '-' + 
        ('00' + (d.getMonth() + 1)).slice(-2) + '-' + 
        ('00' + d.getDate()).slice(-2) + ' ' + 
        ('00' + d.getHours()).slice(-2) + ':' + 
        ('00' + d.getMinutes()).slice(-2) + ':' + 
        ('00' + d.getSeconds()).slice(-2);
    return formattedDate;
  }
  addCustomer(customerData: IAddCustomer) {
    let customerRequestObject = {
      'psuid':customerData.customerInfoForm.psuid,
      'controlNumber':customerData.customerInfoForm.controlNumber,
      'hold':'',
      'uwMarginAdjustment':'',
      'latefeeAmnt':'',
      'filenetId':customerData.customerInfoForm.filenetId,
      'paymentTypeId':customerData.customerInfoForm.paymentType,
      'customerName':customerData.customerInfoForm.customerName,
      'paymentDueDateId':customerData.customerInfoForm.paymentDueDate,
      'tpaNameId':customerData.customerInfoForm.tpaName,
      'cfo':'',
      'status':'',
      'state':customerData.customerInfoForm.state,
      'holdReason':'',
      'claimsWirelineNumber':customerData.customerInfoForm.wirelineNumber,
      'effectiveDate':this.formateDate(customerData.customerInfoForm.effectiveDate),
      'terminationDate':'',
      'custcon':[
                   {
                              'custconFirstNm':customerData.contactDetailsForm[0].firstName,
                              'custconLastNm':customerData.contactDetailsForm[0].lastName,
                              'custconemailTxt':customerData.contactDetailsForm[0].email,
                              'custconphoneNo':customerData.contactDetailsForm[0].phoneNumber,
                              'custcontypeId':'26'
                   },
                   {
                              'custconFirstNm':customerData.contactDetailsForm[1].firstName,
                              'custconLastNm':customerData.contactDetailsForm[1].lastName,
                              'custconemailTxt':customerData.contactDetailsForm[1].email,
                              'custconphoneNo':customerData.contactDetailsForm[1].phoneNumber,
                              'custcontypeId':'63'
                            
                   },
                   {
                              'custconFirstNm':customerData.contactDetailsForm[2].firstName,
                              'custconLastNm':customerData.contactDetailsForm[2].lastName,
                              'custconemailTxt':customerData.contactDetailsForm[2].email,
                              'custconphoneNo':customerData.contactDetailsForm[2].phoneNumber,
                              'custcontypeId':'78'
                            
                   },
                   {
                              'custconFirstNm':customerData.contactDetailsForm[3].firstName,
                              'custconLastNm':customerData.contactDetailsForm[3].lastName,
                              'custconemailTxt':customerData.contactDetailsForm[3].email,
                              'custconphoneNo':customerData.contactDetailsForm[3].phoneNumber,
                              'custcontypeId':'28'
                            
                   },
                   {
                              'custconFirstNm':customerData.contactDetailsForm[4].firstName,
                              'custconLastNm':customerData.contactDetailsForm[4].lastName,
                              'custconemailTxt':customerData.contactDetailsForm[4].email,
                              'custconphoneNo':customerData.contactDetailsForm[4].phoneNumber,
                              'custcontypeId':'29'
                            
                   }
      
                 ],
                "custnote":[ 
                      {
                         "custnoteTxt":customerData.notesForm.notes,
                         "custnotecreateDts":this.notesSaveTimestamp(),
                      }
      
                  ],
         'custbank':[    
             {
              'bankaccTypeId':customerData.bankInfoForm.accountType,
              'bankaccRoutingNo':customerData.bankInfoForm.routingNumber,
              'bankaccNo': customerData.bankInfoForm.accountNumber,
              'bankaccStatusId': customerData.bankInfoForm.status,
              'bankaccBankNm':customerData.bankInfoForm.bankName,
          }
                                                          
      ]
      
  }
    return this.httpClient.post(fromApiContainer.ADD_CUSTOMER, customerRequestObject, this.options);
  }

  getSingleCustomerBillPackages(id) {
    return this.httpClient.get(fromApiContainer.GET_SINGLE_CUSTOMER_BILL_PACKAGES+id, this.options);
  }

  getSingleCustomerDetails(id) {
    let params = new HttpParams();
    params = params.append('customerID', id);

    return this.httpClient.get(fromApiContainer.GET_SINGLE_CUSTOMER_DETAILS, {headers:this.options.headers, params});
  }

  getSingleCustomerSecondaryDetails(id, billPackageID) {
    const url = fromApiContainer.GET_SINGLE_CUSTOMER_SECONDARY_DETAILS+'/'+id+'/billpackage/'+billPackageID;
    return this.httpClient.get(url,this.options);
  }

  getSingleCustomerBankDetails(id) {
    let params = new HttpParams();
    params = params.append('customerId', id);

    return this.httpClient.get(fromApiContainer.GET_SINGLE_CUSTOMER_BANK_DETAILS, {headers:this.options.headers, params});
  }
  getSingleCustomerBillPackageDetails(id) {
    let params = new HttpParams();
    params = params.append('customerId', id);

    return this.httpClient.get(fromApiContainer.GET_SINGLE_CUSTOMER_BILL_PACKAGE_DETAILS, {headers:this.options.headers, params});
  }
  getSingleCustomerContactDetails(id) {
    let params = new HttpParams();
    params = params.append('customerID', id);

    return this.httpClient.get(fromApiContainer.GET_SINGLE_CUSTOMER_CONTACT_DETAILS, {headers:this.options.headers, params});
  }
  getSingleCustomerNotesDetails(id) {
    let params = new HttpParams();
    params = params.append('customerId', id);

    return this.httpClient.get(fromApiContainer.GET_SINGLE_CUSTOMER_NOTES_DETAILS, {headers:this.options.headers, params});
  }
  getSingleCustomerPaymentPlanDetails(id) {
    let params = new HttpParams();
    params = params.append('customerId', id);

    return this.httpClient.get(fromApiContainer.GET_SINGLE_CUSTOMER_PAYMENT_PLAN_DETAILS, {headers:this.options.headers, params});
  }

  getSingleCustomerInvoiceDetails(id) {
    let reqObj = {
      billpackageId: '',
      fromDate: '',
      toDate: 'NaN-NaN-NaN'
    }
    return this.httpClient.post(fromApiContainer.GET_SINGLE_CUSTOMER_INVOICE_DETAILS+id+'&StartIndex=1&NumberOfRecords=10000', reqObj, this.options);
  }

  updateCustomerInfo(updatedData, customerDetails: ISingleCustomerDetails, lateFee) {
    let data = {
      billpackageId: updatedData.billPackage,
      cfo: updatedData.cfo,
      claimsWirelineNumber: updatedData.wirelineNumber,
      controlNumber: customerDetails.controlNumber,
      customerName: customerDetails.customerName,
      customerSubStatus: customerDetails.customerSubStatus,
      effectiveDate: customerDetails.effectiveDate,
      emailAddress: updatedData.emailID,
      filenetId: updatedData.filenetID,
      hold: updatedData.holdInd,
      holdReason: updatedData.holdReason,
      latefeeInd: updatedData.lateFeeInd,
      latefeeAmnt: lateFee,
      paymentDueDateId: updatedData.paymentDueDate,
      paymentTypeId: updatedData.paymentType,
      phoneNumber: updatedData.phone,
      psuid: customerDetails.psuid,
      state: updatedData.state,
      status: updatedData.subStatus,
      terminationDate: updatedData.terminationDate,
      tpaNameId: updatedData.tpaName,
      uwMarginAdjustment: updatedData.uwMarginAdjustment
    };
    return this.httpClient.put(fromApiContainer.UPDATE_CUSTOMER_INFO+customerDetails.customerId, data, this.options);
  }

  updateBankInfo(updatedData: any) {
    return this.httpClient.put(fromApiContainer.UPDATE_BANK_INFO+updatedData.custId, updatedData, this.options);
  }

  getBillPackages(item: IBankBillPackageDetails, customerId) {
    return this.httpClient.get(fromApiContainer.GET_BILL_PACKAGES+customerId+'&billpackageId='+item.billpackages, this.options);
  }

  addNotes(notesData) {
    return this.httpClient.post(fromApiContainer.ADD_NOTES+notesData.custId, notesData, this.options);
  }

  addPaymentPlan(paymentPlanData) {
    const reqObj = {
      payments : paymentPlanData
    };
    return this.httpClient.post(fromApiContainer.ADD_PAYMENT_PLAN, reqObj, this.options);
  }

  removePaymentPlan(item: ISinglePaymentPlan) {
    return this.httpClient.delete(fromApiContainer.REMOVE_PAYMENT_PLAN+item.custppId, this.options);
  }

  updateContact(contacts) {
    let contactData = {
      contacts
    }
    return this.httpClient.put(fromApiContainer.UPDATE_CONTACT_DETAILS, contactData, this.options);    
  }

  getSingleCustomerGraphDetails(id, flag, date ?: any) {
    let reqObj = {
      fromDate: flag === 'resolver' ? toMMDDYYYY1(new Date()) : toMMDDYYYY(date.fromDate),
      toDate: flag === 'resolver' ? toMMDDYYYY(new Date()) : toMMDDYYYY(date.toDate),
    }
    return this.httpClient.post(fromApiContainer.GET_SINGLE_CUSTOMER_GRAPH_DETAILS+String(id), reqObj, this.options);
  }

  getSingleCustomerTransactionTableDetails(id, flag, date ?: any) {
    let reqObj = {
      fromDate: flag === 'resolver' ? toMMDDYYYY1(new Date()) : toMMDDYYYY(date.fromDate),
      toDate: flag === 'resolver' ? toMMDDYYYY(new Date()) : toMMDDYYYY(date.toDate),
    }
    return this.httpClient.post(fromApiContainer.GET_SINGLE_CUSTOMER_TRANSACTION_TABLE_DETAILS+String(id)+'&StartIndex=1&numberOfRecords=10000', reqObj, this.options);
  }
}
