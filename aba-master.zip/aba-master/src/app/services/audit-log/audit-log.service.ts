import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IAuditLogSearchParams } from '../../models/audit-log.model';
import { toHHMMSSFormat } from '../../utils/date-formatter.util';
import { token } from '../../utils/token';
import * as fromApiContainer from '../../api-container';
@Injectable({
  providedIn: 'root'
})
export class AuditLogService {
  options = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      'Accept': 'application/json',
      'UserName': 'N271673',
      'AccessToken': token
    })
  };
  constructor(private httpClient: HttpClient) { }
  
  getAllAuditLogs() {
    return this.httpClient.get(fromApiContainer.GET_ALL_AUDIT_LOGS, this.options);
  }

  searchAuditLogs(auditLogSearchParams: IAuditLogSearchParams) {
    let searchParams = {
      fromDate: auditLogSearchParams.fromDate ? toHHMMSSFormat(auditLogSearchParams.fromDate) : '',
      operation: auditLogSearchParams.operation,
      psuid: auditLogSearchParams.psuid,
      subjectArea: auditLogSearchParams.subjectArea,
      toDate: auditLogSearchParams.toDate ? toHHMMSSFormat(auditLogSearchParams.toDate) : '',
      user: auditLogSearchParams.user
    };
    return this.httpClient.post(fromApiContainer.SEARCH_AUDIT_LOGS,searchParams,this.options);
  }

  getAdditionalDetails(sysuaaId: string) {
    return this.httpClient.get(fromApiContainer.GET_ADDITIONAL_AUDIT_DETAILS+sysuaaId, this.options);
  }

  getCustomerId(auditData) {
    let searchParams = {
      controlNumber: '',
      customerName: '',
      effectiveDate: '',
      psuid: auditData.psuid,
      status: ''
    }
    return this.httpClient.post(fromApiContainer.GET_CUSTOMER_ID,searchParams,this.options);
  }
}
