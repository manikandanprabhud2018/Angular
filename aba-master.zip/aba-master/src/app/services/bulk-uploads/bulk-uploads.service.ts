import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { token } from '../../utils/token';
import * as fromApiContainer from '../../api-container';
@Injectable({
  providedIn: 'root'
})
export class BulkUploadsService {
  options = {
    headers: new HttpHeaders({
      'UserName': 'N271673',
      'AccessToken': token
    })
  };
  constructor(private httpClient: HttpClient) { }

  uploadCustomerExcel(file: File) { 
    let fileData = new FormData();
    fileData.append('excelFile',file);
    return this.httpClient.post(fromApiContainer.UPLOAD_CUSTOMER_EXCEL, fileData, this.options);
  }

  uploadUMAExcel(file: File) { 
    let fileData = new FormData();
    fileData.append('excelUMAFile',file);
    return this.httpClient.post(fromApiContainer.UPLOAD_UMA_EXCEL, fileData, this.options);
  }
}
