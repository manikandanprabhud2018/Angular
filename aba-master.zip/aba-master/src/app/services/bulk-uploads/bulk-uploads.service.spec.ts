import { TestBed } from '@angular/core/testing';

import { BulkUploadsService } from './bulk-uploads.service';

describe('BulkUploadsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BulkUploadsService = TestBed.get(BulkUploadsService);
    expect(service).toBeTruthy();
  });
});
