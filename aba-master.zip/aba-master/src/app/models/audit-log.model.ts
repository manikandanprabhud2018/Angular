export interface IAuditLog {
    errorMessage: string;
    resmessage: string;
    responseObject: IAuditResponse[];
    status: string;
}

export interface IAuditResponse {
    dateandTime: string;
    operation: string;
    psuid: string;
    subjectArea: string;
    sysuaaId: string;
    user: string;
}

export interface IAuditLogSearchParams {
    fromDate: Date;
    toDate: Date;
    user: string;
    psuid: string;
    subjectArea: string;
    operation: string;
}

export interface IAdditionalAuditDetails {
    createdDate ?: string;
    keyFields ?: string;
    modifiedDate ?: string;
    newValue ?: string;
    oldValue ?: string;
}

export interface IAuditLogCustomerSearchDetails {
    errorMessage: string;
    resmessage: string;
    responseObject: IAuditLogCustomerSearch[];
    status: string;
}

export interface IAuditLogCustomerSearch {
    control: string;
    customerID: number;
    customerName: string;
    effectiveDate: string;
    psuid: string;
    reason: string;
    status: string;
    terminationDate: string;
}