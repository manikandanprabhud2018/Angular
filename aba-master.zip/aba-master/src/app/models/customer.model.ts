export interface ISearchResponse {
    errorMessage ?: string;
    resmessage ?: string;
    responseObject ?: ICustomer[];
    status ?: string;
}

export interface ICustomer {
    control ?: string;
    customerID ?: number;
    customerName ?: string;
    effectiveDate ?: string;
    psuid ?: string;
    reason ?: string;
    status ?: string;
    terminationDate ?: string;
}

export interface IAddCustomer {
    customerInfoForm: ICustomerInfo;
    bankInfoForm: IBankInfo;
    contactDetailsForm: IContactDetails[];
    notesForm: INotes;
}

export interface ICustomerInfo {
    customerName: string;
    psuid: string;
    controlNumber: string;
    effectiveDate: Date;
    state: string;
    tpaName: string;
    filenetId: string;
    paymentType: string;
    paymentDueDate: string;
    wirelineNumber: string;
}

export interface IBankInfo {
    bankName: string;
    accountNumber: string;
    routingNumber: string;
    accountType: string;
    status: string;
}

export interface IContactDetails {
    role: string;
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
}

export interface INotes {
    notes: string;
}

export interface ISingleCustomerDetails {
    billPackage?: string;
    cfo?: string;
    claimsWirelineNumber?: string;
    controlNumber?: string;
    customerId?: number;
    customerName?: string;
    customerSubStatus?: string;
    effectiveDate?: string;
    emailAddress?: string;
    filenetId?: string;
    hold?: string;
    holdReason?: string;
    latefeeAmnt?: string;
    latefeeInd?: string;
    organizationTypeCode?: string;
    paymentCode?: string;
    paymentDueDateId?: string;
    paymentTypeId?: string;
    phoneNumber?: string;
    privateExchange?: string;
    psuid?: string;
    state?: string;
    status?: string;
    terminationDate?: string;
    tpaNameId?: string;
    triad?: string;
    uwMarginAdjustment?: string;
}

export interface ISingleBankDetails {
    errorMessage: string;
    resmessage: string;
    responseObject: IBankDetails[];
    status: string;
}

export interface IBankDetails {
    accountStatus: string;
    bankaccBankNm: string;
    bankaccId: string;
    bankaccNo: string;
    bankaccOpenedDT: string;
    bankaccRoutingNo: string;
    bankaccStatusId: string;
    bankaccTypeId: string;
    bankaccValidtnId: string;
    custId: string;
}

export interface IBankBillPackageDetails {
    accountStatus: string;
    amountPercentage: string;
    bankAccId: string;
    bankAccountNo: string;
    billpackages: string;
    custbaId: string;
    custbpId: string;
}

export interface ISingleContactDetails {
    custId: number;
    custconFirstNm: string;
    custconId: string;
    custconLastNm: string;
    custconemailTxt: string;
    custconphoneNo: string;
    custcontypeId: number;
    requesttype: string;
}

export interface ISingleNotesDetails {
    custId: number;
    custnoteId: number;
    custnoteTxt: string;
    custnotecreateDts: string;
    custnoteuserId: string;
}

export interface ISinglePaymentPlan {
    amount: string;
    bacckAccNo: string;
    bacckAccNos?: any[];
    custId: string;
    custbpId: string;
    custppId?: string;
    custppeffDt: string;
    custppexpDt: string;
    custpppaymentAmt: string;
    custpppaymentPct: string;
    custpppayptypId: string;
    custppreasonTxt: string;
}

export interface ISingleInvoiceDetails {
    errorMessage: string;
    resmessage: string;
    responseObject: IInvoiceResponse[];
    status: string;
}

export interface IInvoiceResponse {
    billpackageId: string;
    custftfundpaidDt: string;
    invoiceId: number;
    invoiceblmonthId: number;
    invoicedraftDt: string;
    invoicedueAmt: number;
    invoicedueDt: string;
    invoiceprepardDt: string;
    invoicesrcsysNo: string;
}

export interface ISingleGraphDetails {
    adminFee: string;
    citiBalance: string;
    claim: string;
    claimPaid: string;
    claimTotal: string;
    outofBalance: string;
    stopLossFee: string;
    totalInvoiceAmount: string;
    totalInvoiceCount: string;
    trf: string;
}

export interface ISingleTransactionTableDetails {
    debitorCredit: string;
    invoice: string;
    invoiceId: string;
    paidAmount: string;
    paidDate: string;
    paymentError: string;
    requestedAmount: string;
    requestedDate: string;
    transactionType: string;
}

export interface ISingleSecondaryCustomerDetails {
    billpackageEmailId ?: string;
    cfo ?: string;
    customerBillIndicator ?: string;
    customerSubStatus ?: string;
    latefeeAmount ?: string;
    orgTypeCode ?: string;
    phoneNumber ?: string;
    traidCode ?: string;
    umaAmount ?: string;
}