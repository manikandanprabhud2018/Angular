export interface IInvoiceResponse {
    billPackageId ?: string;
    controlNumber ?: string;
    customerBillIndicator ?: string;
    draftDate ?: string;
    dueDate ?: string;
    invoiceDate ?: string;
    invoiceId ?: string;
    invoiceSeqId ?: string;
    paidDate ?: string;
    prepareDate ?: string;
    psuqid ?: string;
    status ?: string;
    totalAmount ?: string;
    triad ?: string;
}

export interface IInvoiceSearchParams {
    psuid ?: string;
    controlNumber ?: string;
    invoiceId ?: string;
    triad ?: string;
    status ?: string;
    fromDate ?: Date;
    toDate ?: Date;
}

export interface IInvoiceSearchResponse {
    status: string;
    resmessage: string;
    errorMessage: string;
    responseObject: IInvoiceResponse[]
}

export interface IAdditionalInvoiceResponse {
    adjustmentAmt: number;
    adminFeeAdjAmt: number;
    aggrgatAlAdjAmt: number;
    annualLiabilyAmt: number;
    billpackageId: string;
    carArgName: string;
    carOrgName: string;
    conEmailAdd: string;
    conFirstName: string;
    conLastName: string;
    conPhoneNumer: string;
    currentIfCrgAmt: number;
    currntAdmFeeAmt: number;
    currntAggrSlAmt: number;
    currntSlPremAmt: number;
    currntTrmResAmt: number;
    custbpId: number;
    custftfundpaidDt: string;
    dueAmt: number;
    ee1DepSSubscNo: number;
    eeAllDepSubscNo: number;
    eeChildSubscNo: number;
    eeChildrnSubscNo: number;
    eeChildsSubscNo: number;
    eeSpouseSubscNo: number;
    eeSubscribersNo: number;
    familySubscNo: number;
    invoiceId: number;
    invoicedraftDt: string;
    invoicedueAmt: string;
    invoicedueDt: string;
    invoiceprepardDt: string;
    invoicesrcsysNo: string;
    openingBalancAmt: number;
    paymentRecvAmt: number;
    priExArgName: string;
    priExOrgName: string;
    retroActivityAmt: number;
    retroAddMonthNo: number;
    retroAddsNo: number;
    retroAdmFeeAmt: number;
    retroAggrSlAmt: number;
    retroSlPremAmt: number;
    retroTermMthsNo: number;
    retroTermsNo: number;
    retroTrmResAmt: number;
    slPremiumAdjAmt: number;
    termResrvAdjAmt: number;
    totalLivesNo: number;
}

export interface ISavePaymentReqObj {
    custId: string;
    bacckAccNo: string;
    custbpId: string;
    custppeffDt: string;
    custpppayptypId: string;
    amount: any;
    custppexpDt: string;
    custpppaymentAmt: string;
    custpppaymentPct: string;
    custppreasonTxt: string;
}