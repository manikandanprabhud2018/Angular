import { DisableControlDirective } from './directives/disableField.directive';

export const directives: any[] = [
    DisableControlDirective
];

export * from './directives/disableField.directive';