// Domain
export const DOMAIN: string = 'https://qainternal.aetna.com/abaService3/';
// export const DOMAIN: string = 'https://devinternal.aetna.com/abaService/';

export const INDEX_INFO: string = 'StartIndex=1&NumberOfRecords=10000';

// Login 
export const LOGIN: string = DOMAIN+'rest/login';

// Home Page APIs
export const GET_RECENTLY_ADDED_CUSTOMERS: string = DOMAIN+'rest/v1/customers/recentlyadded';

// Customer Page APIs
export const GET_ALL_CUSTOMERS: string = DOMAIN+'rest/customers/listAll?'+INDEX_INFO;
export const GET_MISSING_BANK_INFO: string = DOMAIN+'rest/v1/customers/missingBankInformation?'+INDEX_INFO;
export const GET_MISSING_INVOICE_INFO: string = DOMAIN+'rest/v1/customers/missingInvoices?'+INDEX_INFO;
export const GET_MISSING_CUSTOMER_SETUP_INFO: string = DOMAIN+'rest/v1/customers/missingCustomerSetup?'+INDEX_INFO;
export const GET_MISSING_CLAIMS_WIRELINE__INFO: string = DOMAIN+'rest/v1/customers/missingWirelineNumber?'+INDEX_INFO;
export const GET_LATEFEE_CUSTOMER_INFO: string = DOMAIN+'rest/v1/customers/latefeecustomers?'+INDEX_INFO;

export const SEARCH_CUSTOMER: string = DOMAIN+'rest/customers/search?'+INDEX_INFO;
export const GET_LOOKUP_DETAILS: string = DOMAIN+'rest/lookupDetails';
export const ADD_CUSTOMER: string = DOMAIN+'rest/customers/save';

export const GET_SINGLE_CUSTOMER_DETAILS: string = DOMAIN+'rest/customers/display';
export const GET_SINGLE_CUSTOMER_SECONDARY_DETAILS: string = DOMAIN+'rest/v1/customers';
export const GET_SINGLE_CUSTOMER_BANK_DETAILS: string = DOMAIN+'rest/banking/display';
export const GET_SINGLE_CUSTOMER_BILL_PACKAGE_DETAILS: string = DOMAIN+'rest/v1/banking/bankandbillpackages';
export const GET_SINGLE_CUSTOMER_BILL_PACKAGES: string = DOMAIN+'rest/v1/customers/billpackages?customerId=';
export const GET_SINGLE_CUSTOMER_CONTACT_DETAILS: string = DOMAIN+'rest/contacts/listAllContacts';
export const GET_SINGLE_CUSTOMER_NOTES_DETAILS: string = DOMAIN+'rest/v1/customers/notes';
export const GET_SINGLE_CUSTOMER_PAYMENT_PLAN_DETAILS: string = DOMAIN+'rest/customers/listAllPaymentPlans';
export const GET_SINGLE_CUSTOMER_INVOICE_DETAILS: string = DOMAIN+'rest/customers/listCustomerInvoices?customerID=';
export const GET_SINGLE_CUSTOMER_GRAPH_DETAILS: string = DOMAIN+'rest/v1/invoices/transaction/totalcount?customerId=';
export const GET_SINGLE_CUSTOMER_TRANSACTION_TABLE_DETAILS: string = DOMAIN+'rest/v1/invoices/transaction?customerId=';

export const UPDATE_CUSTOMER_INFO: string = DOMAIN+'rest/customers/update?customerID=';
export const UPDATE_BANK_INFO: string = DOMAIN+'rest/banking/update?bankaccId=';
export const UPDATE_CONTACT_DETAILS: string = DOMAIN+'rest/contacts/update';

export const GET_BILL_PACKAGES: string = DOMAIN+'rest/v1/customers/billpackages/bankaccountnumbers?customerId=';

export const ADD_NOTES: string = DOMAIN+'rest/v1/customers/notes?customerId=';
export const ADD_PAYMENT_PLAN: string = DOMAIN+'rest/payments/save';
export const REMOVE_PAYMENT_PLAN: string = DOMAIN+'rest/payments/delete?custppId=';

//Invoice Page APIs

export const GET_ALL_INVOICES: string = DOMAIN+'rest/invoice/listAllInvoices?'+INDEX_INFO;
export const SEARCH_INVOICE: string = DOMAIN+'rest/v1/invoices/search?'+INDEX_INFO;
export const GET_ADDITIONAL_INVOICE_DETAILS: string = DOMAIN+'rest/v1/invoices?invoiceId=';

//Audit Logs Page APIs
export const GET_ALL_AUDIT_LOGS: string = DOMAIN+'rest/v1/auditlog/listAll?StartIndex=1&NumberOfRecords=10';
export const SEARCH_AUDIT_LOGS: string = DOMAIN+'rest/v1/auditlog/search?'+INDEX_INFO;
export const GET_ADDITIONAL_AUDIT_DETAILS: string = DOMAIN+'rest/v1/auditlog?sysuaaId=';
export const GET_CUSTOMER_ID: string = DOMAIN+'rest/customers/search?'+INDEX_INFO;

//Bulk Upload Page APIs
export const UPLOAD_CUSTOMER_EXCEL: string = DOMAIN+'rest/v1/customers/bulk-upload';
export const UPLOAD_UMA_EXCEL: string = DOMAIN+'rest/v1/customers/bulkuma-upload';
