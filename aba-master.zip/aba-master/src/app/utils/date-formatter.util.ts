// DateFormatter 'mm/dd/yyyy' format
export function toMMDDYYYY(date): string {
    return (date.getMonth() + 1) + '/' + date.getDate() + '/' +  date.getFullYear();
}

export function toMMDDYYYY1(date): string {
    return (date.getMonth() + 1) + '/' + date.getDate() + '/' +  (date.getFullYear()-1);
}

export function toHHMMSSFormat(date): string {
    let formattedDate: string = 
        date.getFullYear() + '-' + 
        ('00' + (date.getMonth() + 1)).slice(-2) + '-' + 
        ('00' + date.getDate()).slice(-2) + ' ' + 
        ('00' + date.getHours()).slice(-2) + ':' + 
        ('00' + date.getMinutes()).slice(-2) + ':' + 
        ('00' + date.getSeconds()).slice(-2) + '.0';
    return formattedDate;
}