import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
//Forms Module
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
//Http Module
import { HttpClientModule } from '@angular/common/http';
//ngx-bootstrap modules
import { TabsModule } from 'ngx-bootstrap/tabs';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { ModalModule } from 'ngx-bootstrap/modal';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { CarouselModule } from 'ngx-bootstrap/carousel';
//Chart Module
import { ChartsModule } from 'ng2-charts';
//AppRouting module
import { AppRoutingModule } from './app-routing.module';
//Third Party Modules
import { DataTableModule } from "angular-6-datatable";
//components
import * as fromComponents from './components';
//Modals 
import * as fromModals from './modals';
//Directives
import * as fromDirectives from './directives';
//services
import * as fromServices from './services';

@NgModule({
  declarations: [
    // Components
    ...fromComponents.components,
    // Directive
    ...fromDirectives.directives,
    // Modals
    ...fromModals.modals
  ],
  imports: [
    //Angular Modules
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    //Data Table Module
    DataTableModule,
    //Chart Module
    ChartsModule,
    //ngx-bootstrap modules
    BsDatepickerModule.forRoot(),
    TypeaheadModule.forRoot(),
    ModalModule.forRoot(),
    TabsModule.forRoot(),
    AccordionModule.forRoot(),
    CarouselModule.forRoot()
  ],
  providers: [...fromServices.services],
  bootstrap: [fromComponents.AppComponent],
  entryComponents: [...fromModals.modals]
})
export class AppModule { }
