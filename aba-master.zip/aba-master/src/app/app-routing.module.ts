import { RouterModule , Routes } from '@angular/router';
import { NgModule } from '@angular/core';

import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/dashboard/home/home.component';
import { CustomersComponent } from './components/dashboard/customers/customers.component';
import { CustomerDetailsComponent } from './components/dashboard/customer-details/customer-details.component';
import { InvoicesComponent } from './components/dashboard/invoices/invoices.component';
import { AuditLogsComponent } from './components/dashboard/audit-logs/audit-logs.component';
import { ReportsComponent } from './components/dashboard/reports/reports.component';
import { BulkUploadsComponent } from './components/dashboard/bulk-uploads/bulk-uploads.component';
import { ContactComponent } from './components/dashboard/contact/contact.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { CustomerResolver } from './services/customer/customer.resolver';

const appRoutes: Routes = [
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: 'dashboard',
        component: DashboardComponent,
        children: [
            {
                path: 'home',
                component: HomeComponent
            },
            {
                path: 'customers',
                component: CustomersComponent
            },
            {
                path: 'customers/:id',
                component: CustomerDetailsComponent,
                resolve: {
                    singleCustomerData: CustomerResolver
                }
            },
            {
                path: 'invoices',
                component: InvoicesComponent
            },
            {
                path: 'auditlogs',
                component: AuditLogsComponent
            },
            {
                path: 'reports',
                component: ReportsComponent
            },
            {
                path: 'bulkuploads',
                component: BulkUploadsComponent
            },
            {
                path: 'contact',
                component: ContactComponent
            }
        ]
    },
    {
        path: '**',
        redirectTo:'login'
    }
]
@NgModule({
    declarations: [],
    imports: [
      RouterModule.forRoot(appRoutes)
    ],
    providers: [CustomerResolver],
    bootstrap: [],
    exports: [RouterModule]
  })

  export class AppRoutingModule { }