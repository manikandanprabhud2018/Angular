import { ViewAuditModalComponent } from './view-audit-modal/view-audit-modal.component';
import { ViewInvoiceModalComponent } from './view-invoice-modal/view-invoice-modal.component';

export const modals: any[] = [
    ViewAuditModalComponent,ViewInvoiceModalComponent
];

export * from './view-audit-modal/view-audit-modal.component';
export * from './view-invoice-modal/view-invoice-modal.component';
