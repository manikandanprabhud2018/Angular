import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { IAdditionalAuditDetails, IAuditResponse, IAuditLogCustomerSearchDetails } from '../../models/audit-log.model';
import { AuditLogService } from '../../services/audit-log/audit-log.service';

@Component({
  selector: 'aba-view-audit-modal',
  templateUrl: './view-audit-modal.component.html',
  styleUrls: ['./view-audit-modal.component.css']
})
export class ViewAuditModalComponent {

  additionalDetails: IAdditionalAuditDetails[];
  basicDetails: IAuditResponse;
  constructor(
    public bsModalRef: BsModalRef,
    private auditLogService: AuditLogService,
    private router: Router
  ) {}

  viewCustomer(basicDetails) {
    this.auditLogService.getCustomerId(basicDetails).subscribe((data: IAuditLogCustomerSearchDetails) => {
      this.bsModalRef.hide();
      this.router.navigate(['dashboard/customers',data.responseObject[0].customerID]);
    });
  }
}
