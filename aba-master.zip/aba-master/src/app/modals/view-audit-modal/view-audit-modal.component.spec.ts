import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAuditModalComponent } from './view-audit-modal.component';

describe('ViewAuditModalComponent', () => {
  let component: ViewAuditModalComponent;
  let fixture: ComponentFixture<ViewAuditModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewAuditModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAuditModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
